To compile: mpiCC MPI_Ramsey.cpp -o partyMPI
To run:

            First generate the machines file by typing "bccd-snarfhosts" 
            and hitting the Enter key.  Don't type the quotes.
            
            time mpirun -np 8 -machinefile ~/machines-openmpi ./partyMPI

            The above command runs it with 8 MPI processes.  Change the 8 to
            the number of MPI processes you want.
