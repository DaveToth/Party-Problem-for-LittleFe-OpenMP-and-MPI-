/**
 * This is an OpenMP program that tests 335544320000 graphs to see if they
 * can help us find a tighter bound on R(5,5).
 */

#include <iostream>
#include <math.h>
#include <omp.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

// Constants
//const long long NUM_GRAPHS = 335544320000LL; // A long long has a maximum value of 9223372036854775807.
const long long NUM_GRAPHS = 2147483648LL; // = about 5 minutes and 50 seconds on my LittleFe (real AKA wall clock) using 2 OpenMP threads.
const int RED = 0;
const int BLUE = 1;
const int NUM_VERTICES = 45;
const int NUM_EDGES = 990;

// Function Prototypes
void generateNextGraph(int graph[]);
bool hasK5(const int graph[]);
#define convert2Dto1D(i,j) ((NUM_VERTICES * i) + j - (((i + 1) * (i + 2)) / 2))

// Main
int main(int argc, char *argv[])
{
	bool specialGraphFound = false;

	// Set up OpenMP code.
	int numThreads; // The number of threads to use for OpenMP
	numThreads = atoi(argv[1]); //The number of threads will be entered on the
	// command line.
	omp_set_num_threads(numThreads);

	long long graphsPerThread = NUM_GRAPHS/numThreads;

	// Start the parallelism with OpenMP!!!
	#pragma omp parallel
	{
		int offset[NUM_EDGES]; // Holds the binary representation of the offset.
								// The offset is used to calculate the first graph
								// in each set of graphs.
		int baseGraph[NUM_EDGES]; // The first graph in the set of graphs to test.
		int graph[NUM_EDGES]; // The graph in each set of graphs to test.
		long long remainder; // The offset from the base graph of the first graph in
							// each range.  Used to calculate the binary value of the
							// offset from the base graph.
		int id = omp_get_thread_num(); // The ID number of a thread for OpenMP

		// Calculate the first graph for each thread to test.

		// Initializing the arrays
		for(int i=0; i < NUM_EDGES; i++)
		{
			baseGraph[i] = 0;
			offset[i] = 0;
			graph[i] = 0;
		}

		remainder = graphsPerThread * id;

		// Calculate first graph for each thread to test.

		// Translates offset into binary and stores the bits into the offset array.
		for(int x = 39; x >= 0; x--)
		{
			long long powResult = pow(2.0f, x);
			if(remainder >= powResult)
			{
				offset[989-x] = 1;
				remainder -= powResult;
			}
			else
			{
				offset[989-x] = 0;
			}
		}

		// Puts sum of offset and base graph into graph array so that
		// graph array holds the bits for the first graph to test.
		for(int m = NUM_EDGES-1; m >= 0; m--)
		{
			graph[m] = graph[m]+offset[m]+baseGraph[m];

			if(graph[m] == 2)
			{
				graph[m] = 0;
				graph[m-1]++;
			}
			else if(graph[m] == 3)
			{
				graph[m] = 1;
				graph[m-1]++;
			}
		}

		// Tests the first graph.
		if(!hasK5(graph))
		{
			#pragma omp critical
			{
				cout << "Special Graph Found:\n" << endl;
				specialGraphFound = true;
				for(int i=0; i < NUM_EDGES; i++)
				{
					cout << graph[i];
				}
				cout << endl;
			}
		}

		for(long long i=0LL; i < graphsPerThread; i++)
		{
			generateNextGraph(graph);

			// Test graph. If a graph with no K5 is found, print out that graph.
			if(!hasK5(graph))
			{
				#pragma omp critical
				{
					cout << "Special Graph Found:\n" << endl;
					specialGraphFound = true;

					for(int i=0; i < NUM_EDGES; i++)
					{
						cout << graph[i];
					}
					cout << endl;
				}
			}
		}
	}

	if(!specialGraphFound)
	{
		cout << "No special graph found...  Not a big surprise." << endl;
	}

	return 0;
}//end main


/* This function tests the graph passed in to see if it contains a K5.
 * @param graph - The array holding the graph.
 * @return - Returns whether the graph contains a K5.
 */
bool hasK5(const int graph[])
{
	bool foundK5 = false;

	// initialize counters
	int vertex1 = 0;
	int vertex2 = 1;
	int vertex3 = 2;
	int vertex4 = 3;
	int vertex5 = 4;

	/* These five nested while loops select the 5 vertices that
		 we will test to see if they form a K5. The outermost while loop
		 selects the smallest numbered vertex. The next while loop selects the
		 second smallest numbered vertex and so on... The set of while loops test
		 every possible set of five vertices that could form a K5 until they find
		 one or have tested every possible set.
		 */

	while(!foundK5 && vertex1 < NUM_VERTICES - 4)
	{
		while(!foundK5 && vertex2 < NUM_VERTICES - 3)
		{
			while(!foundK5 && vertex3 < NUM_VERTICES - 2)
			{
				while(!foundK5 && vertex4 < NUM_VERTICES - 1)
				{
					while(!foundK5 && vertex5 < NUM_VERTICES)
					{
						if(graph[convert2Dto1D(vertex1, vertex2)] == RED &&
								graph[convert2Dto1D(vertex1, vertex3)] == RED &&
								graph[convert2Dto1D(vertex1, vertex4)] == RED &&
								graph[convert2Dto1D(vertex1, vertex5)] == RED &&
								graph[convert2Dto1D(vertex2, vertex3)] == RED &&
								graph[convert2Dto1D(vertex2, vertex4)] == RED &&
								graph[convert2Dto1D(vertex2, vertex5)] == RED &&
								graph[convert2Dto1D(vertex3, vertex4)] == RED &&
								graph[convert2Dto1D(vertex3, vertex5)] == RED &&
								graph[convert2Dto1D(vertex4, vertex5)] == RED)
						{
							foundK5 = true;
						}
						else if(graph[convert2Dto1D(vertex1, vertex2)] == BLUE &&
								graph[convert2Dto1D(vertex1, vertex3)] == BLUE &&
								graph[convert2Dto1D(vertex1, vertex4)] == BLUE &&
								graph[convert2Dto1D(vertex1, vertex5)] == BLUE &&
								graph[convert2Dto1D(vertex2, vertex3)] == BLUE &&
								graph[convert2Dto1D(vertex2, vertex4)] == BLUE &&
								graph[convert2Dto1D(vertex2, vertex5)] == BLUE &&
								graph[convert2Dto1D(vertex3, vertex4)] == BLUE &&
								graph[convert2Dto1D(vertex3, vertex5)] == BLUE &&
								graph[convert2Dto1D(vertex4, vertex5)] == BLUE)
						{
							foundK5 = true;
						}
						vertex5++;
					}
					vertex4++;
					vertex5 = vertex4 + 1;
				}
				vertex3++;
				vertex4 = vertex3 + 1;
				vertex5 = vertex4 + 1;
			}
			vertex2++;
			vertex3 = vertex2 + 1;
			vertex4 = vertex3 + 1;
			vertex5 = vertex4 + 1;
		}
		vertex1++;
		vertex2 = vertex1 + 1;
		vertex3 = vertex2 + 1;
		vertex4 = vertex3 + 1;
		vertex5 = vertex4 + 1;
	}

	return foundK5;
}


/* This function generates the next graph.
 * @param graph - The array holding the graph.
 */
void generateNextGraph(int graph[])
{
	bool carry = false;
	int index = NUM_EDGES - 1;

	do
	{
		//add 1 and check for carry
		if(graph[index] == 0)
		{
			carry = false;
			graph[index] = 1;
		}
		else
		{
			carry = true;
			graph[index] = 0;
		}

		index--;
	}
	while(carry && index >= 0);
}

