To compile: g++ -fopenmp OpenMP_Ramsey.cpp -o partyOpenMP

To run: time ./partyOpenMP 2

The above example for running the program runs it with 2 threads.  If you want the number of threads equal to the number of cores on the CPU since the LittleFe CPUs are dual core, use 2.  You can use a different number instead of 2 if you want a different number of threads. 


