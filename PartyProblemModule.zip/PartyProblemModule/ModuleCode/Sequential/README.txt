To compile: g++ Sequential_Ramsey.cpp -o partySeq
To run:     time ./partySeq
